<?php

define('BASE_PATH', __DIR__);
define('STUBS_PATH', __DIR__ . DIRECTORY_SEPARATOR . 'stubs');

<?php

namespace JackCompiler\CompileEngine\Compilations\Constants;

class CompilationConstants
{
    public const VAR_TYPES = 'int|char|boolean';
}
